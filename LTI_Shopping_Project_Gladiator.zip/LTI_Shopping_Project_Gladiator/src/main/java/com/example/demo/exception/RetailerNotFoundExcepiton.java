package com.example.demo.exception;

public class RetailerNotFoundExcepiton extends Exception {
	public RetailerNotFoundExcepiton(String msg) {
		super(msg);
	}
}





