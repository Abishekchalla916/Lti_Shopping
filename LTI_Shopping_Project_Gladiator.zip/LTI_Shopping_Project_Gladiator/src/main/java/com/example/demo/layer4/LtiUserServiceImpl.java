package com.example.demo.layer4;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.LtiUser;
import com.example.demo.layer3.LtiUserRepository;

@Service
public class LtiUserServiceImpl implements LtiUserService {
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Autowired
	LtiUserRepository userRepo;
	
	public LtiUserServiceImpl() {
		System.out.println("LtiUserServiceImpl() is running....");
	}
	
	public LtiUser findUserByIdService(String uRef) {
		System.out.println("findUserByIdService() code is running...");
		TypedQuery <LtiUser> user = entityManager.createQuery("select u from LtiUser u where u.email= : x",LtiUser.class);
		user.setParameter("x",uRef);
		LtiUser userOrd = user.getSingleResult();
		System.out.println("placeOrderService() running..."+userOrd.getUserName());
		return userOrd;
	}

	public List<LtiUser> findAllUsersService() {
		System.out.println("findAllUsersService() code is running...");
		return userRepo.selectAllUser();
	}

	public void insertNewUser(LtiUser dRef) {
		System.out.println("insertNewUser() code is running...");
		userRepo.insertUser(dRef);
		
	}
	public LtiUser placeOrderService(String uRef) {
		// TODO Auto-generated method stub
		TypedQuery <LtiUser> user = entityManager.createQuery("select u from LtiUser u where u.email= : x",LtiUser.class);
		user.setParameter("x",uRef);
		LtiUser userOrd = user.getSingleResult();
		System.out.println("placeOrderService() running..."+userOrd.getUserName());
		return userOrd;
	}

	@Override
	public void updateUserService(LtiUser uRef) {
		// TODO Auto-generated method stub
		userRepo.updateUser(uRef);
	}

	@Override
	public LtiUser validateService(String email, String password) {
		TypedQuery <LtiUser> query = entityManager.createQuery("select u from LtiUser u where u.email= : x",LtiUser.class);
		query.setParameter("x",email);
		LtiUser ltiuser = query.getSingleResult();
		if(ltiuser==null)
		return null;
		else {
			TypedQuery <LtiUser> query2 = entityManager.createQuery("select u from LtiUser u where u.password= : y",LtiUser.class);
			query2.setParameter("y",password);
			LtiUser ltiuser2 = query2.getSingleResult();
			if(ltiuser2==null)
				return null;
			else {
				return ltiuser2;
			}
		}
	}
	
	public LtiUser resetPasswordService(String email) {
		System.out.println("updateUserService() in service is running...");
		TypedQuery <LtiUser> user = entityManager.createQuery("select u from LtiUser u where u.email= : x",LtiUser.class);
		user.setParameter("x", email);
		LtiUser userPwd = user.getSingleResult();
		//System.out.println(userPwd.getUserName());
		if(userPwd == null) {
			System.out.println("User not found...");
		}
		else {			
			return userPwd;
		}
		
		return userPwd;
	}

}
