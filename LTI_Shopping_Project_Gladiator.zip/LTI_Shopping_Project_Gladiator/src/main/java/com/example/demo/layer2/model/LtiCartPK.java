package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the LTI_CART database table.
 * 
 */
@Embeddable
public class LtiCartPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ORD_ID", insertable=false, updatable=false)
	private long ordId;

	@Column(name="PROD_ID", insertable=false, updatable=false)
	private long prodId;

	public LtiCartPK(long ordId, long prodId) {
		this.ordId=ordId;
		this.prodId=prodId;
	}
	public LtiCartPK() {
		
	}
	public long getOrdId() {
		return this.ordId;
	}
	public void setOrdId(long ordId) {
		this.ordId = ordId;
	}
	public long getProdId() {
		return this.prodId;
	}
	public void setProdId(long prodId) {
		this.prodId = prodId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof LtiCartPK)) {
			return false;
		}
		LtiCartPK castOther = (LtiCartPK)other;
		return 
			(this.ordId == castOther.ordId)
			&& (this.prodId == castOther.prodId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.ordId ^ (this.ordId >>> 32)));
		hash = hash * prime + ((int) (this.prodId ^ (this.prodId >>> 32)));
		
		return hash;
	}
}