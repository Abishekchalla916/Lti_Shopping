package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the LTI_USER database table.
 * 
 */
@Entity
@Table(name="LTI_USER")
@NamedQuery(name="LtiUser.findAll", query="SELECT l FROM LtiUser l")
public class LtiUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="USER_ID")
	private long userId;

	private String address;

	private String city;

	private String email;

	private Long mobile;

	private String password;

	private Integer postalcode;

	@Column(name="STATE")
	private String state;

	@Column(name="USER_NAME")
	private String userName;

	//bi-directional many-to-one association to LtiOrder
	@OneToMany(mappedBy="ltiUser", fetch=FetchType.LAZY)
	private List<LtiOrder> ltiOrders;

	public LtiUser() {
	}

	public long getUserId() {
		return this.userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getMobile() {
		return this.mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getPostalcode() {
		return this.postalcode;
	}

	public void setPostalcode(Integer postalcode) {
		this.postalcode = postalcode;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<LtiOrder> getLtiOrders() {
		return this.ltiOrders;
	}

	public void setLtiOrders(List<LtiOrder> ltiOrders) {
		this.ltiOrders = ltiOrders;
	}

	public LtiOrder addLtiOrder(LtiOrder ltiOrder) {
		getLtiOrders().add(ltiOrder);
		ltiOrder.setLtiUser(this);

		return ltiOrder;
	}

	public LtiOrder removeLtiOrder(LtiOrder ltiOrder) {
		getLtiOrders().remove(ltiOrder);
		ltiOrder.setLtiUser(null);

		return ltiOrder;
	}

}