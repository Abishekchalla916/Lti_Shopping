package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the LTI_ORDER database table.
 * 
 */
@Entity
@Table(name="LTI_ORDER")
@NamedQuery(name="LtiOrder.findAll", query="SELECT l FROM LtiOrder l")
public class LtiOrder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ORD_ID")
	private long ordId;

	@Column(name="DELIVERY_STS")
	private String deliverySts;

	@Column(name="MODE_OF_PAYMENT")
	private String modeOfPayment;

	@Temporal(TemporalType.DATE)
	@Column(name="ORDER_DATE")
	private Date orderDate;

	@Column(name="TOTAL_ORDER_PRICE")
	private Double totalOrderPrice;

	//bi-directional many-to-one association to LtiCart
	@OneToMany(mappedBy="ltiOrder", fetch=FetchType.LAZY)
	private List<LtiCart> ltiCarts;

	//bi-directional many-to-one association to LtiUser
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private LtiUser ltiUser;
	
	
	public LtiOrder() {
	}

	public long getOrdId() {
		return this.ordId;
	}

	public void setOrdId(long ordId) {
		this.ordId = ordId;
	}

	public String getDeliverySts() {
		return this.deliverySts;
	}

	public void setDeliverySts(String deliverySts) {
		this.deliverySts = deliverySts;
	}

	public String getModeOfPayment() {
		return this.modeOfPayment;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	public Date getOrderDate() {
		return this.orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Double getTotalOrderPrice() {
		return this.totalOrderPrice;
	}

	public void setTotalOrderPrice(Double totalOrderPrice) {
		this.totalOrderPrice = totalOrderPrice;
	}

	public List<LtiCart> getLtiCarts() {
		return this.ltiCarts;
	}

	public void setLtiCarts(List<LtiCart> ltiCarts) {
		this.ltiCarts = ltiCarts;
	}

	public LtiCart addLtiCart(LtiCart ltiCart) {
		getLtiCarts().add(ltiCart);
		ltiCart.setLtiOrder(this);

		return ltiCart;
	}

	public LtiCart removeLtiCart(LtiCart ltiCart) {
		getLtiCarts().remove(ltiCart);
		ltiCart.setLtiOrder(null);

		return ltiCart;
	}

	@JsonIgnore
	public LtiUser getLtiUser() {
		return this.ltiUser;
	}

	public void setLtiUser(LtiUser ltiUser) {
		this.ltiUser = ltiUser;
	}

}