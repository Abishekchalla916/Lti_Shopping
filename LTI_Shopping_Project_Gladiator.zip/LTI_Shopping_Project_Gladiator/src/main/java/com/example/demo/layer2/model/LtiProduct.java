package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;


/**
 * The persistent class for the LTI_PRODUCT database table.
 * 
 */
@Entity
@Table(name="LTI_PRODUCT")
@NamedQuery(name="LtiProduct.findAll", query="SELECT l FROM LtiProduct l")
public class LtiProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PROD_ID")
	private long prodId;

	@Column(name="PROD_BRAND")
	private String prodBrand;

	@Column(name="PROD_DESCRIPTION")
	private String prodDescription;

	@Column(name="PROD_NAME")
	private String prodName;

	@Column(name="PROD_PRICE")
	private Double prodPrice;

	@Column(name="STOCKS_REMAINING")
	private Integer stocksRemaining;

	//bi-directional many-to-one association to LtiCart
	@OneToMany(mappedBy="ltiProduct", fetch=FetchType.LAZY)
	private List<LtiCart> ltiCarts;

	//bi-directional many-to-one association to LtiRetailer
	
	@ManyToOne
	@JoinColumn(name="RETAILER_ID")
	private LtiRetailer ltiRetailer;

	
	
	public LtiProduct() {
	}

	public long getProdId() {
		return this.prodId;
	}

	public void setProdId(long prodId) {
		this.prodId = prodId;
	}

	public String getProdBrand() {
		return this.prodBrand;
	}

	public void setProdBrand(String prodBrand) {
		this.prodBrand = prodBrand;
	}

	public String getProdDescription() {
		return this.prodDescription;
	}

	public void setProdDescription(String prodDescription) {
		this.prodDescription = prodDescription;
	}

	public String getProdName() {
		return this.prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public Double getProdPrice() {
		return this.prodPrice;
	}

	public void setProdPrice(Double prodPrice) {
		this.prodPrice = prodPrice;
	}

	public Integer getStocksRemaining() {
		return this.stocksRemaining;
	}

	public void setStocksRemaining(Integer stocksRemaining) {
		this.stocksRemaining = stocksRemaining;
	}

	public List<LtiCart> getLtiCarts() {
		return this.ltiCarts;
	}

	public void setLtiCarts(List<LtiCart> ltiCarts) {
		this.ltiCarts = ltiCarts;
	}

	public LtiCart addLtiCart(LtiCart ltiCart) {
		getLtiCarts().add(ltiCart);
		ltiCart.setLtiProduct(this);

		return ltiCart;
	}

	public LtiCart removeLtiCart(LtiCart ltiCart) {
		getLtiCarts().remove(ltiCart);
		ltiCart.setLtiProduct(null);

		return ltiCart;
	}
	
	@JsonIgnore
	public LtiRetailer getLtiRetailer() {
		return this.ltiRetailer;
	}

	public void setLtiRetailer(LtiRetailer ltiRetailer) {
		this.ltiRetailer = ltiRetailer;
	}

}