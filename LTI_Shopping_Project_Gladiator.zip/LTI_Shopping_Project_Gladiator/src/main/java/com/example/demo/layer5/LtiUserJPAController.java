package com.example.demo.layer5;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.example.demo.layer3.LtiUserRepository;
import com.example.demo.layer4.LTICartService;
import com.example.demo.layer4.LTIOrderService;
import com.example.demo.layer4.LtiUserService;
import com.example.demo.exception.OrderNotFoundException;
import com.example.demo.exception.UserNotFoundExcepiton;
import com.example.demo.layer2.model.LoginDTO;
import com.example.demo.layer2.model.LtiCart;
import com.example.demo.layer2.model.LtiCartPK;
import com.example.demo.layer2.model.LtiOrder;
import com.example.demo.layer2.model.LtiProduct;
import com.example.demo.layer2.model.LtiUser;
import com.example.demo.layer2.model.OrderProductDTO;


@CrossOrigin(origins = "*", value = "*")
@RestController
public class LtiUserJPAController {

	@Autowired
	LtiUserService userService; //here it should be service calls
	
	@Autowired
	LTIOrderService ordService;
	
	@Autowired
	LTICartService cartService;
	
	public LtiUserJPAController() {
		System.out.println("LtiUserJPAController()....");
		
	}
	
	@RequestMapping(path="/getJPAUsers") //localhost:8086/getJPAUsers
	public List<LtiUser> getAllUsers() {
		System.out.println("getAllUsers");
		return userService.findAllUsersService();
	}
	

	@GetMapping
	@RequestMapping(path="/getJPAUser/{uno}") // localhost:8086/getJPAUser/101
	public LtiUser getUser(@PathVariable("uno") int userIdToFind) throws UserNotFoundExcepiton 
	{
		System.out.println("getUser : "+userIdToFind);
		LtiUser foundUser = null;
		foundUser = userService.findUserByIdService(userIdToFind);

	
		if(foundUser == null) {
			UserNotFoundExcepiton userIdException = new UserNotFoundExcepiton("UserId Not Found "+ userIdToFind);
			System.out.println("UserId Not Found");
			throw userIdException;
		}
		return foundUser;
	}
	
	@PostMapping
	@RequestMapping(path="/addJPAAddUser") // 
	public void addNewUser(@RequestBody LtiUser userToInsert) throws UserNotFoundExcepiton 
	{
		LtiUser newUser = new LtiUser();
		newUser.setUserName(userToInsert.getUserName());
		newUser.setEmail(userToInsert.getEmail());
		newUser.setPassword(userToInsert.getPassword());
		newUser.setMobile(userToInsert.getMobile());
		newUser.setAddress(userToInsert.getAddress());
		newUser.setCity(userToInsert.getCity());
		newUser.setState(userToInsert.getState());
		newUser.setPostalcode(userToInsert.getPostalcode());
		
		System.out.println("addNewUser :  "+newUser.getUserName()+" "+newUser.getEmail()+" "+
				newUser.getPassword()+" "+newUser.getMobile()+" "+newUser.getAddress()+" "+
				newUser.getCity()+" "+newUser.getState()+" "+newUser.getPostalcode()); 
		userService.insertNewUser(newUser);
	}
	
	@PostMapping
	@RequestMapping(path="/addUserOrder/{email}") //http://localhost:8086/addUserOrder
	public void addUserOrder(@PathVariable("email") String userIdToFind,@RequestBody OrderProductDTO opt) throws OrderNotFoundException{
		LtiUser userOrd = userService.placeOrderService(userIdToFind);
		if(userOrd == null) {
			OrderNotFoundException userOrderException = new OrderNotFoundException("User Order Not Found ");
			System.out.println("User id Not Found");
			throw userOrderException;
		}
		else {
		
		LtiOrder ord = opt.getLtiOrder();
		ordService.insertOrder(ord);
		ord.setDeliverySts("ND");
		Date d = new Date();
		ord.setOrderDate(d);
		ord.setLtiUser(userOrd);
		ordService.updateOrder(ord);
		
		List<LtiProduct> lp = opt.getLtiProduct();
		List<Integer> qty = opt.getQty();
		List<LtiCart> cl = new ArrayList<LtiCart>();
		int s = lp.size();
		System.out.println(s);
		for(int i=0;i<s;i++) {
			System.out.println("aaa"+i);
			LtiCart c = new LtiCart();
			LtiCartPK cpk = new LtiCartPK(ord.getOrdId(),lp.get(i).getProdId()); 
			c.setId(cpk);
			c.setLtiOrder(ord);
			c.setLtiProduct(lp.get(i));
			c.setProdPrice(lp.get(i).getProdPrice());
			c.setQty(qty.get(i));
			c.setProdTotal(lp.get(i).getProdPrice()*qty.get(i));
			cartService.insertCart(c);	
			cl.add(c);
			System.out.println("loop"+i);
		}
		
		ord.setLtiCarts(cl);
		ordService.updateOrder(ord);
		
		
		
		List<LtiOrder> ordList = new ArrayList<LtiOrder>();
		ordList.add(ord);
		for(LtiOrder a:ordList) {
			System.out.println(a);
		}
		
			userOrd.setLtiOrders(ordList);
			userService.updateUserService(userOrd);
		}
		
	}
	
	@GetMapping
	@RequestMapping(path= "/login/")
	public LoginDTO validate(@RequestBody LoginDTO ldto) throws UserNotFoundExcepiton {
		LtiUser u = userService.validateService(ldto.getEmail(), ldto.getPassword());
		if(u==null) {
		UserNotFoundExcepiton ex = new UserNotFoundExcepiton(null);
		throw ex;
		}
		return ldto;
	}
	@PostMapping
	@RequestMapping(path="/modifyJPAUser") //http://localhost:8086/modifyJPAUser
	public void modifyUser(@RequestBody LtiUser userEmailToFind) throws UserNotFoundExcepiton 
	{
 
		LtiUser uDet = userService.resetPasswordService(userEmailToFind.getEmail());
		System.out.println("Records modified....");
		if(uDet==null) {
			UserNotFoundExcepiton userIdException = new UserNotFoundExcepiton("User Email Not Found ");
			System.out.println("User Email Not Found");
			throw userIdException;
		}
		else {
			uDet.setPassword(userEmailToFind.getPassword());
			userService.updateUserService(uDet);
		}
	
	}
		
}
