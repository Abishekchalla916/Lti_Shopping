package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the LTI_CART database table.
 * 
 */
@Entity
@Table(name="LTI_CART")
@NamedQuery(name="LtiCart.findAll", query="SELECT l FROM LtiCart l")
public class LtiCart implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LtiCartPK id;
	
	@Column(name="PROD_PRICE")
	private Double prodPrice;

	@Column(name="PROD_TOTAL")
	private Double prodTotal;

	@Column(name="QTY")
	private Integer qty;

	//bi-directional many-to-one association to LtiOrder
	
	@ManyToOne()
	@JoinColumn(name="ORD_ID", insertable = false, updatable = false)
	private LtiOrder ltiOrder;

	//bi-directional many-to-one association to LtiProduct
	
	@ManyToOne()
	@JoinColumn(name="PROD_ID", insertable = false, updatable = false)
	private LtiProduct ltiProduct;

	public LtiCart() {
	}

	public LtiCartPK getId() {
		return this.id;
	}

	public void setId(LtiCartPK id) {
		this.id = id;
	}

	public Double getProdPrice() {
		return this.prodPrice;
	}

	public void setProdPrice(Double prodPrice) {
		this.prodPrice = prodPrice;
	}

	public Double getProdTotal() {
		return this.prodTotal;
	}

	public void setProdTotal(Double prodTotal) {
		this.prodTotal = prodTotal;
	}

	public Integer getQty() {
		return this.qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}
	@JsonIgnore
	public LtiOrder getLtiOrder() {
		return this.ltiOrder;
	}

	public void setLtiOrder(LtiOrder ltiOrder) {
		this.ltiOrder = ltiOrder;
	}
	@JsonIgnore
	public LtiProduct getLtiProduct() {
		return this.ltiProduct;
	}

	public void setLtiProduct(LtiProduct ltiProduct) {
		this.ltiProduct = ltiProduct;
	}

}