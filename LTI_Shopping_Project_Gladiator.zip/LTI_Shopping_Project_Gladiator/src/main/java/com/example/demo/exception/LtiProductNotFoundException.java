package com.example.demo.exception;

public class LtiProductNotFoundException extends Exception{
	public LtiProductNotFoundException(String msg) {
		super(msg);
	}
}
