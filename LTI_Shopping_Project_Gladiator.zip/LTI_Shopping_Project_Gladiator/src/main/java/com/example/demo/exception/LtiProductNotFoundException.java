package com.example.demo.exception;

public class LtiProductNotFoundException extends RuntimeException{
	public LtiProductNotFoundException(String msg) {
		super(msg);
	}
}
