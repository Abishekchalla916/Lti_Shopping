package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.LtiUser;

@Service
public interface LtiUserService {
	void insertNewUser(LtiUser dRef);
	LtiUser findUserByIdService(String userId);
	List<LtiUser> findAllUsersService();
	public LtiUser placeOrderService(String uRef);
	void updateUserService(LtiUser uRef);
	public LtiUser validateService(String email, String password);
	public LtiUser resetPasswordService(String email);

}
