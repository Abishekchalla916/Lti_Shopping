package com.example.demo.exception;

public class UserNotFoundExcepiton extends Exception {
	public UserNotFoundExcepiton(String msg) {
		super(msg);
	}
}
