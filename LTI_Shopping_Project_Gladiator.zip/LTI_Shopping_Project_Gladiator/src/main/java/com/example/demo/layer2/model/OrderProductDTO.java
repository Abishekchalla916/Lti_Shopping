package com.example.demo.layer2.model;


import java.util.List;

public class OrderProductDTO {
private LtiOrder ltiOrder;
private List <LtiProduct> ltiProduct;
private List <Integer> qty;

public LtiOrder getLtiOrder() {
	return ltiOrder;
}
public void setLtiOrder(LtiOrder ltiOrder) {
	this.ltiOrder = ltiOrder;
}
public List<LtiProduct> getLtiProduct() {
	return ltiProduct;
}
public void setLtiProduct(List<LtiProduct> ltiProduct) {
	this.ltiProduct = ltiProduct;
}
public List<Integer> getQty() {
	return qty;
}
public void setQty(List<Integer> qty) {
	this.qty = qty;
}



}
