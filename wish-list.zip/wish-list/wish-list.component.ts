import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LtiProductService } from '../lti-product.service';
import { LtiProduct } from '../lti-product/LtiProduct';

@Component({
  selector: 'app-wish-list',
  templateUrl: './wish-list.component.html',
  styleUrls: ['./wish-list.component.css']
})
export class WishListComponent implements OnInit {

  constructor(private productService : LtiProductService,private route : Router) { }
  compareProds:LtiProduct[]=this.productService.getWishListProducts();

  oneProd(pd:LtiProduct){
    console.log(pd);
    this.productService.setSingleProdToShowService(pd);
    this.route.navigate(['SingleProduct'])
  }
  ngOnInit(): void {
  }

}
