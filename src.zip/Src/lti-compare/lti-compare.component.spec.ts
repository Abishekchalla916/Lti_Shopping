import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LtiCompareComponent } from './lti-compare.component';

describe('LtiCompareComponent', () => {
  let component: LtiCompareComponent;
  let fixture: ComponentFixture<LtiCompareComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LtiCompareComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LtiCompareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
