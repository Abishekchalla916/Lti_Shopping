import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LtiProductService } from '../lti-product.service';
import { LtiProduct } from '../lti-product/LtiProduct';

@Component({
  selector: 'app-lti-compare',
  templateUrl: './lti-compare.component.html',
  styleUrls: ['./lti-compare.component.css']
})
export class LtiCompareComponent implements OnInit {

  constructor(private productService:LtiProductService,private route:Router) {
    this.compareProds=this.productService.getCompareProducts();
    console.log("In compare const() "+this.compareProds);
  }

  compareProds:LtiProduct[];
  oneProd(pd:LtiProduct){
    console.log(pd);
    this.productService.setSingleProdToShowService(pd);
    this.route.navigate(['SingleProduct'])
  }

  ngOnInit(): void {
  }

}
