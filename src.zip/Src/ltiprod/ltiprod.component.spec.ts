import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LtiprodComponent } from './ltiprod.component';

describe('LtiprodComponent', () => {
  let component: LtiprodComponent;
  let fixture: ComponentFixture<LtiprodComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LtiprodComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LtiprodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
