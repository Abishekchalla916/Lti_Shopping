import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LtiProductService } from '../lti-product.service';
import { LtiProduct } from '../lti-product/LtiProduct';
import { LtiRetailer } from '../lti-product/LtiRetailer';

@Component({
  selector: 'app-ltiprod',
  templateUrl:'./ltiprod.component.html',
  styleUrls: ['./ltiprod.component.css']
})
export class  LtiprodComponent implements OnInit {

  constructor(private  productService  : LtiProductService,private route : Router) { }

  allProducts:LtiProduct[]=[];
  allProductsRev:LtiProduct[]=[];
  prodToAdd : LtiProduct=new LtiProduct();
  useless : String;
  dummyRetailer : LtiRetailer=new LtiRetailer();
  singleRetailer : LtiRetailer=new LtiRetailer();
  retailerIdToFind : number=10;
  prodIdtoFind : number;
  singleProduct:LtiProduct=new LtiProduct();
  prodIdToDelete : number;
  retailerId:number;
 
  singleProdIdToShow:number;
  len:number;
  loadAllProducts() {
    console.log('loadAllProducts ts...');
    this.productService.loadAllProductsService().subscribe(
      (data: LtiProduct[])=> { this.allProducts = data; console.log("all prods seedha"+this.allProducts);}, 
      (err) => { console.log(err);}
    );
    this.len=this.allProducts.length;
    console.log(this.len);
    for(var i=0;i<this.len;i++)
      this.allProductsRev.push(this.allProducts[this.len-i-1]);
    console.log("all prod reverse");
    console.log(this.allProductsRev);
  }

  loadSingleProduct(){
    console.log("load single prod ts.."+this.singleProduct);
    this.productService.loadSingleProductService(this.prodIdtoFind).subscribe(
      (data : LtiProduct)=>{this.singleProdToShow=data;console.log(this.singleProdToShow);},
    );

  }
  addProduct(){
    //this.prodToAdd;
    //this.prodToAdd.ltiRetailer=this.dummyRetailer;
    console.log("In add adding....");
    console.log("In add adding...."+this.prodToAdd)
    this.productService.addProduct(this.prodToAdd,this.retailerId).subscribe(
    (data:String)=>{this.useless=data}
    );
  }

  getSingleRetailer(){
    console.log("In single retailer servicce"+this.retailerIdToFind);
    this.productService.loadSingleRetailerService(this.retailerIdToFind).subscribe(
      (data : LtiRetailer)=>{this.singleRetailer=data;console.log(this.singleRetailer)},
    );
  }
  

  indexOfelement:number;
  singleProdToShow: LtiProduct;

  oneProd(pd:LtiProduct){
    console.log(pd);
    this.productService.setSingleProdToShowService(pd);
    this.route.navigate(['SingleProduct'])
  }

  setOfProdIdInCart=new Set();
  cartProds:LtiProduct[]=[];
  //click:boolean=false;
  addProdToCart(prod:LtiProduct){
    if(this.setOfProdIdInCart.has(Number(prod.prodId))) return;
    
    console.log(prod.prodId+"Checking..."+this.setOfProdIdInCart.has(Number(prod.prodId)));
    console.log(this.setOfProdIdInCart);
    this.cartProds.push(prod);
    this.setOfProdIdInCart.add(Number(prod.prodId));
    console.log("Set of prod id"+this.setOfProdIdInCart);
    
  }
  showCartProducts(){
    if(this.cartProds.length==0) {
      alert("Cart is Empty");
      return;
    }
    console.log(this.cartProds);
    this.productService.setCart(this.cartProds);
    this.route.navigate(['Cart']);
  }

  compareProds:LtiProduct[]=[];
  setOfProdIdInCompare=new Set();

  addProdToCompare(prod : LtiProduct){
    if(this.setOfProdIdInCompare.size==4){
      alert("Can't add More than 4 products  to compare");
      return;
    }
    this.setOfProdIdInCompare.add(prod.prodId);
    this.compareProds.push(prod);
  }

  showCompareProducts(){
    console.log(this.compareProds);
    this.productService.setCompareProducts(this.compareProds);
    this.route.navigate(['Compare']);
  }
 
  Name="Name";Low="Low";High="High";Apple="Apple";OnePlus="OnePlus";Samsung="Samsung";All="All";Xiaomi="Xiaomi";
  temp:LtiProduct[]=[];
  allProdsCopy:LtiProduct[]=[];
  sort(by: String) {
       
      if(by== "Low"){
        this.allProducts = this.allProducts.sort((low, high) => low.prodPrice - high.prodPrice);
      }

      else if(by=="High"){
        this.allProducts = this.allProducts.sort((low, high) => high.prodPrice - low.prodPrice);
      }

      else if(by=="Name"){
        this.allProducts = this.allProducts.sort(function (low, high) {
          if (low.prodBrand+" "+low.prodName < high.prodBrand+" "+high.prodName)  return -1;
          else if (low.prodBrand+" "+low.prodName > high.prodBrand+" "+high.prodName) return 1;
          else  return 0;            
        })
      }

      else if(by=="Apple"||by=="OnePlus"||by=="Samsung"||by=="Xiaomi"){
        console.log(by);
        if(this.allProdsCopy.length!=0)
          this.allProducts=this.allProdsCopy;
        this.temp=[];
        for(var i=0;i<this.allProducts.length;i++)
          if(this.allProducts[i].prodBrand==by)
            this.temp.push(this.allProducts[i]);
        this.allProdsCopy=this.allProducts;
        this.allProducts=this.temp;
        console.log(this.temp);
      }

      else if(by=="All"){
        if(this.allProducts.length==0)
          this.allProducts=this.allProdsCopy;
      }
     
      else{
        this.allProducts = this.allProducts.sort((low, high) =>low.prodPrice - high.prodPrice);
      }
    return this.allProducts;
  }

  ngOnInit(): void {
  }

}
/*
case "Apple":{
        for(var i=0;i<this.allProducts.length;i++)
          if(this.allProducts[i].prodBrand=="Apple")
            this.temp.push(this.allProducts[i]);
        this.allProducts=this.temp;
        break;
      }
 case "Samsung":{
        for(var i=0;i<this.allProducts.length;i++)
        if(this.allProducts[i].prodBrand=="Apple")
          this.temp.push(this.allProducts[i]);
        this.allProducts=this.temp;
        break;
      }
      case "Xaomi":{
        for(var i=0;i<this.allProducts.length;i++)
        if(this.allProducts[i].prodBrand=="Apple")
          this.temp.push(this.allProducts[i]);
        this.allProducts=this.temp;
      break;
      }

*/